ECHOLOC 1.2.6 (2026-11-11) - offline version
by Luis Quesada Torres - https://level102.com

Open index.html in a web browser (Chrome, Edge, Firefox or Safari). No internet needed.
Play with headphones.

The font (Liberation Mono, SIL Open Font License 1.1) and its notices: OFL.txt, THIRD_PARTY_NOTICES.txt.
(c) 2026 Luis Quesada Torres. All rights reserved (the font keeps its own licence).
